import json
import os
from flask_cors import CORS, cross_origin
from flask import Flask, request, make_response
import pandas as pd
import solution

app = Flask(__name__)
cors = CORS(app)

@app.route('/triangleType', methods=['POST', 'GET'])
@cross_origin()
def triangleType():
    excel = request.files['file']
    excel.save(os.getcwd() + '/' + excel.filename)
    df = pd.read_excel(excel.filename)
    df.insert(loc=4, column='real', value='')
    df.insert(loc=5, column='result', value='')
    for i in range(df.shape[0]):
        df.loc[i, 'real'] = solution.triangleType(df.loc[i, 'a'], df.loc[i, 'b'], df.loc[i, 'c'])
        if str(df.loc[i, 'real']) != str(df.loc[i, 'expect']):
            df.loc[i, 'result'] = "未通过测试"
        else:
            df.loc[i, 'result'] = "通过测试"
    result = json.dumps(df.to_dict(orient='records'))
    response = make_response(result)
    return response

@app.route('/computerSales', methods=['POST', 'GET'])
@cross_origin()
def computerSales():
    excel = request.files['file']
    excel.save(os.getcwd() + '/' + excel.filename)
    df = pd.read_excel(excel.filename)
    df.insert(loc=4, column='real', value='')
    df.insert(loc=5, column='result', value='')
    for i in range(df.shape[0]):
        df.loc[i, 'real'] = solution.computerSales(df.loc[i, '主机'], df.loc[i, '显示器'], df.loc[i, '外设'])
        if str(df.loc[i, 'real']) != str(df.loc[i, 'expect']):
            df.loc[i, 'result'] = "未通过测试"
        else:
            df.loc[i, 'result'] = "通过测试"
    result = json.dumps(df.to_dict(orient='records'))
    response = make_response(result)
    return response


@app.route('/calendar', methods=['POST', 'GET'])
@cross_origin()
def calendar():
    excel = request.files['file']
    excel.save(os.getcwd() + '/' + excel.filename)
    df = pd.read_excel(excel.filename)
    df.insert(loc=4, column='real', value='')
    df.insert(loc=5, column='result', value='')
    for i in range(df.shape[0]):
        df.loc[i, 'real'] = solution.calendar(df.loc[i, 'year'], df.loc[i, 'month'], df.loc[i, 'day'])
        if str(df.loc[i, 'real']) != str(df.loc[i, 'expect']):
            df.loc[i, 'result'] = "未通过测试"
        else:
            df.loc[i, 'result'] = "通过测试"
    result = json.dumps(df.to_dict(orient='records'))
    response = make_response(result)
    return response


@app.route('/charge', methods=['POST', 'GET'])
@cross_origin()
def charge():
    excel = request.files['file']
    excel.save(os.getcwd() + '/' + excel.filename)
    df = pd.read_excel(excel.filename)
    df.insert(loc=3, column='real', value='')
    df.insert(loc=4, column='result', value='')
    for i in range(df.shape[0]):
        df.loc[i, 'real'] = solution.charge(df.loc[i, 'minute'], df.loc[i, 'times'])
        if int(df.loc[i, 'real']) != int(df.loc[i, 'expect']):
            df.loc[i, 'result'] = "未通过测试"
        else:
            df.loc[i, 'result'] = "通过测试"
    result = json.dumps(df.to_dict(orient='records'))
    response = make_response(result)
    return response


if __name__ == '__main__':
    app.run()  # 可以指定运行的主机IP地址，端口，是否开启调试模式
