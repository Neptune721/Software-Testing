import requests
import pandas as pd
urlBase = 'http://124.70.163.146:8080/api/v1'

def getRes():
    res = {}
    res['SG_Int_001_001'] = requests.get(url=urlBase + '/CommodityInfoService/CommodityInfo?CommodityID=100001').text
    res['SG_Int_001_002'] = requests.get(url=urlBase + '/CommodityInfoService/CommodityInfo?CommodityID=200001').text
    # # 只能添加一次
    res['SG_Int_002_001'] = requests.get(url=urlBase + '/GameLibService/AddToGameLibrary?BuyerID=10001&CommodityID=100007').text
    res['SG_Int_002_002'] = requests.get(url=urlBase + '/GameLibService/AddToGameLibrary?BuyerID=10001&CommodityID=100001').text
    # # 只能添加一次
    res['SG_Int_003_001'] = requests.post(url=urlBase + '/EvaluationService/AddEvaluation?UserID=10001&CommodityID=100007&Evaluation=verygood').text
    res['SG_Int_003_002'] = requests.post(url=urlBase + '/EvaluationService/AddEvaluation?UserID=10001&CommodityID=100001&Evaluation=verygood').text
    res['SG_Int_004_001'] = requests.post(url=urlBase + '/LoginService/Login?UserID=10001&Password=123456').text
    res['SG_Int_004_002'] = requests.post(url=urlBase + '/LoginService/Login?UserID=10006&Password=123456').text
    res['SG_Int_004_003'] = requests.post(url=urlBase + '/LoginService/Login?UserID=10008&Password=123456').text
    res['SG_Int_004_004'] = requests.post(url=urlBase + '/LoginService/Login?UserID=10046&Password=111111').text
    res['SG_Int_005_001'] = requests.get(url=urlBase + '/CommodityInfoService/CommodityInfo?CommodityID=100001').text
    res['SG_Int_005_002'] = requests.get(url=urlBase + '/CommodityInfoService/CommodityInfo?CommodityID=105423').text
    res['SG_Int_006_001'] = requests.get(url=urlBase + '/SearchService/SearchByName?name=原神').text
    res['SG_Int_006_002'] = requests.get(url=urlBase + '/SearchService/SearchByName?name=古神').text
    res['SG_Int_007_001'] = requests.get(url=urlBase + '/ShoppingCartService/AddShoppingCart?UserID=10001&CommodityID=100002').text
    res['SG_Int_007_002'] = requests.get(url=urlBase + '/ShoppingCartService/AddShoppingCart?UserID=10001&CommodityID=100013').text
    res['SG_Int_008_001'] = requests.get(url=urlBase + '/ShoppingCartService/ShoppingCartRemove?BuyerID=10001&CommodityID=100002').text
    res['SG_Int_008_002'] = requests.get(url=urlBase + '/ShoppingCartService/ShoppingCartRemove?BuyerID=10001&CommodityID=100010').text
    res['SG_Int_009_001'] = requests.get(url=urlBase + '/WishListService/AddWishList?UserID=10001&CommodityID=100006').text
    res['SG_Int_009_002'] = requests.get(url=urlBase + '/WishListService/AddWishList?UserID=10001&CommodityID=100013').text
    res['SG_Int_010_001'] = requests.get(url=urlBase + '/WishListService/WishListRemove?BuyerID=10001&CommodityID=100006').text
    res['SG_Int_010_002'] = requests.get(url=urlBase + '/WishListService/WishListRemove?BuyerID=10001&CommodityID=100024').text
    return res


total = 0
success = 0
fail = 0
df = pd.read_excel('集成测试.xlsx')
print(df)
df.insert(loc=2, column='real', value='')
df.insert(loc=3, column='result', value='')
res = getRes()
for i in range(df.shape[0]):
    total += 1
    df.loc[i,'real'] = res[str(df.loc[i, 'id'])]
    if str(df.loc[i, 'real']) != str(df.loc[i, 'expect']):
        df.loc[i, 'result'] = "未通过测试"
        fail += 1
    else:
        df.loc[i, 'result'] = "通过测试"
        success += 1
df.to_csv('result.csv')
print('共测试了',total,'个测试用例,成功:',success,'失败:',fail)
