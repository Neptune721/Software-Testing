import datetime


def triangleType(a, b, c):
    if a == 0:
        return "a不能为0"
    if b == 0:
        return "b不能为0"
    if c == 0:
        return "c不能为0"
    if a < 0:
        return "a不能是负数"
    if b < 0:
        return "b不能是负数"
    if c < 0:
        return "c不能是负数"
    if a > 1000:
        return "a不在取值范围内"
    if b > 1000:
        return "b不在取值范围内"
    if c > 1000:
        return "c不在取值范围内"
    if a + c > b and a + b > c and c + b > a:
        if a == b == c:
            return "等边三角形"
        elif a == b or b == c or a == c:
            return "等腰三角形"
        else:
            return "普通三角形"
    else:
        return "非三角形"


def computerSales(x1, x2, x3):
    if x1 == -1:
        return "统计该销售员本月的销售总额"
    if x1 <= 0 or x2 <= 0 or x3 <= 0:
        return "销量必须均为正数"
    if x1 > 70 or x2 > 80 or x3 > 90:
        return "销量超过最大值"
    sales = 25 * x1 + 30 * x2 + 45 * x3
    if sales <= 1000:
        reward = sales * 0.1
    elif sales <= 1800:
        reward = sales * 0.15
    else:
        reward = sales * 0.2
    return str(int(reward))


def calendar(year, month, day):
    if (year < 2000 or year > 2100) and (month < 1 or month > 12) and (day < 1 or day > 31):
        return '用例不合规'
    if year < 2000 or year > 2100:
        return '年份越界'
    if year % 400 == 0:
        is_leap = 1
    elif year % 4 == 0 and year % 100 != 0:
        is_leap = 1
    else:
        is_leap = 0
    if month < 1 or month > 12:
        return '月份越界'
    if month in [1, 3, 5, 7, 8, 10, 12]:
        if day < 1 or day > 31:
            return '天数越界'
    elif month in [4, 6, 9, 11]:
        if day < 1 or day > 30:
            return '天数越界'
    elif month == 2:
        if is_leap == 0 and (day < 1 or day > 28):
            return '天数越界'
        if is_leap == 1 and (day < 1 or day > 29):
            return '天数越界'
    try:
        dateResult = datetime.datetime.strptime('-'.join([str(year), str(month), str(day)]), '%Y-%m-%d').date()
    except Exception as e:
        return str(e)
    return str(dateResult + datetime.timedelta(days=1))


def charge(phone_time, missed_payments):
    basic_charge = 25
    fee_per_min = 0.15
    fee = 0
    if phone_time < 0:
        return "通话分钟数不能为负数"
    if missed_payments < 0:
        return "不按时缴费次数不能为负数"
    if phone_time > 44640:
        return "通话分钟数超过限制"
    if missed_payments > 11:
        return "不按时缴费次数超过限制"
    if 0 <= phone_time <= 60 and missed_payments <= 1:
        return 0.01
    elif 60 < phone_time <= 120 and missed_payments <= 2:
        return 0.015
    elif 120 < phone_time <= 180 and missed_payments <= 3:
        return 0.02
    elif 180 < phone_time <= 300 and missed_payments <= 3:
        return 0.025
    elif 300 < phone_time and missed_payments <= 6:
        return 0.03
    else:
        return 0
