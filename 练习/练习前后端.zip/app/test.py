import pandas as pd
import solution
import json

df = pd.read_excel('triangle_1.xlsx')
df.insert(loc=4, column='real', value='')
df.insert(loc=5, column='result', value='')
for i in range(df.shape[0]):
    df.loc[i, 'real'] = solution.triangleType(df.loc[i, 'a'], df.loc[i, 'b'], df.loc[i, 'c'])
    if str(df.loc[i,'real']) != str(df.loc[i,'expect']):
        df.loc[i, 'result'] = "未通过测试"
    else:
        df.loc[i, 'result'] = "通过测试"
da = json.dumps(df.to_dict(orient='records'))
print(da)