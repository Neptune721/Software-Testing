<template>
  <div id="app">
    <el-tabs type="border-card">
      <el-tab-pane label="判断三角形类型">
        <triangle></triangle>
      </el-tab-pane>
      <el-tab-pane label="万年历问题">
        <calendar></calendar>
      </el-tab-pane>
      <el-tab-pane label="电脑销售系统">
        <computer-sale></computer-sale>
      </el-tab-pane>
      <el-tab-pane label="电信收费问题系统">
        <charge></charge>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import triangle from './components/triangle.vue'
import computerSale from './components/computerSale.vue'
import calendar from './components/calendar.vue'
import charge from './components/charge.vue'
export default {
  name: 'App',
  components: {triangle, computerSale, calendar, charge}
}
</script>

<style>
.question
{
  font-family: 微软雅黑 Light,serif;
  color: red;
}
</style>
