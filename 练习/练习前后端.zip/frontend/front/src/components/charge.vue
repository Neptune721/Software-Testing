<template>
  <div>
    <h1>电信收费问题</h1>
    <el-divider></el-divider>
    <h2>边界值法</h2>
    <p class="question">
      对应问题7：研究一个与我们的生活息息相关的电信收费问题系统。</p>
    <div>
      <el-upload
        class="upload-demo"
        action="http://localhost:5000/charge"
        :on-preview="handlePreview"
        :on-remove="handleRemove"
        :before-remove="beforeRemove"
        multiple
        :limit="100"
        :on-exceed="handleExceed"
        :on-success="Success"
        :file-list="fileList">
        <el-button type="success">上传测试用例</el-button>
        <div class="el-upload__tip">只能上传excel文件</div>
      </el-upload>
    </div>
    <template>
      <el-table
        stripe
        :data="tableData"
        style="width: 100%">
        <el-table-column
          prop="id"
          label="用例编号"
          width="180">
        </el-table-column>
        <el-table-column
          prop="minute"
          label="分钟数"
          width="180">
        </el-table-column>
        <el-table-column
          prop="times"
          label="不按时缴费次数"
          width="180">
        </el-table-column>
        <el-table-column
          prop="expect"
          label="预期结果"
          width="180">
        </el-table-column>
        <el-table-column
          prop="real"
          label="实际结果"
          width="180">
        </el-table-column>
        <el-table-column
          prop="result"
          label="是否通过"
          width="180">
        </el-table-column>
      </el-table>
    </template>
  </div>
</template>

<script>
export default {
  name: 'charge',
  data () {
    return {
      tableData: [],
      fileList: []
    }
  },
  methods:
    {
      handleRemove (file, fileList) {
        console.log(file, fileList)
      },
      handlePreview (file) {
        console.log(file)
      },
      handleExceed (files, fileList) {
        this.$message.warning(`当前限制选择 100 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`)
      },
      // eslint-disable-next-line no-unused-vars
      beforeRemove (file, fileList) {
        return this.$confirm(`确定移除 ${file.name}？`)
      },

      // eslint-disable-next-line no-unused-vars
      Success (response, file, fileList) {
        this.tableData = response
      }
    }
}
</script>

<style scoped>

</style>
