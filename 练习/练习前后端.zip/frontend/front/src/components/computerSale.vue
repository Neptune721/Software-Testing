<template>
  <div>
    <h1>电脑销售系统</h1>
    <el-divider></el-divider>
    <h2>边界值法</h2>
    <p class="question">
      对应问题4：电脑销售系统，主机（25￥单位价格，每月最多销售的数量为70），显示器（30￥单位价格，每月最多销售数量为80），外设（45￥单位价格，每月最多销售的数量为90）；每个销售员每月至少销售一台完整的机器，当系统的主机这个变量接受到-1值的时候，系统自动统计该销售员本月的销售总额。当销售额小于等于1000（包括1000）按照10%提佣金，当销售额在1000-1800之间（包括1800）的时候按照15%提佣金，当销售额大于1800时按照20%提佣金。（用边界值方法分析和设计测试用例）</p>
    <div>
      <el-upload
        class="upload-demo"
        action="http://localhost:5000/computerSales"
        :on-preview="handlePreview"
        :on-remove="handleRemove"
        :before-remove="beforeRemove"
        multiple
        :limit="100"
        :on-exceed="handleExceed"
        :on-success="Success"
        :file-list="fileList">
        <el-button type="success">上传测试用例</el-button>
        <div class="el-upload__tip">只能上传excel文件</div>
      </el-upload>
    </div>
    <template>
      <el-table
        stripe
        :data="tableData"
        style="width: 100%">
        <el-table-column
          prop="id"
          label="用例编号"
          width="180">
        </el-table-column>
        <el-table-column
          prop="主机"
          label="主机销量"
          width="180">
        </el-table-column>
        <el-table-column
          prop="显示器"
          label="显示器销量"
          width="180">
        </el-table-column>
        <el-table-column
          prop="外设"
          label="外设销量"
          width="180">
        </el-table-column>
        <el-table-column
          prop="expect"
          label="预期结果"
          width="180">
        </el-table-column>
        <el-table-column
          prop="real"
          label="实际结果"
          width="180">
        </el-table-column>
        <el-table-column
          prop="result"
          label="是否通过"
          width="180">
        </el-table-column>
      </el-table>
    </template>
  </div>
</template>

<script>
export default {
  name: 'computerSale',
  data () {
    return {
      tableData: [],
      fileList: []
    }
  },
  methods:
    {
      handleRemove (file, fileList) {
        console.log(file, fileList)
      },
      handlePreview (file) {
        console.log(file)
      },
      handleExceed (files, fileList) {
        this.$message.warning(`当前限制选择 100 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`)
      },
      // eslint-disable-next-line no-unused-vars
      beforeRemove (file, fileList) {
        return this.$confirm(`确定移除 ${file.name}？`)
      },

      // eslint-disable-next-line no-unused-vars
      Success (response, file, fileList) {
        this.tableData = response
      }
    }
}
</script>

<style scoped>

</style>
