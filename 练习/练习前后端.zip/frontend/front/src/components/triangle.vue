<template>
  <div>
  <h1>判断三角形类型</h1>
  <el-divider></el-divider>
  <h2>边界值法</h2>
    <p class="question">对应问题1：判断三角形类型（用边界值分析和设计测试用例）</p>
    <div>
      <el-upload
        class="upload-demo"
        action="http://localhost:5000/triangleType"
        :on-preview="handlePreview2"
        :on-remove="handleRemove2"
        :before-remove="beforeRemove2"
        multiple
        :limit="100"
        :on-exceed="handleExceed2"
        :on-success="Success2"
        :file-list="fileList2">
        <el-button type="success">上传测试用例</el-button>
        <div class="el-upload__tip">只能上传excel文件</div>
      </el-upload>
    </div>
    <template>
      <el-table
        stripe
        :data="tableData2"
        style="width: 100%">
        <el-table-column
          prop="id"
          label="用例编号"
          width="180">
        </el-table-column>
        <el-table-column
          prop="a"
          label="a"
          width="180">
        </el-table-column>
        <el-table-column
          prop="b"
          label="b"
          width="180">
        </el-table-column>
        <el-table-column
          prop="c"
          label="c"
          width="180">
        </el-table-column>
        <el-table-column
          prop="expect"
          label="预期结果"
          width="180">
        </el-table-column>
        <el-table-column
          prop="real"
          label="实际结果"
          width="180">
        </el-table-column>
        <el-table-column
          prop="result"
          label="是否通过"
          width="180">
        </el-table-column>
      </el-table>
    </template>
  <el-divider></el-divider>
  <h2>等价类法</h2>
  <p class="question">对应问题9：判断三角形类型（等价类方法分别分析和设计测试用例）</p>
  <div>
    <el-upload
      class="upload-demo"
      action="http://localhost:5000/triangleType"
      :on-preview="handlePreview"
      :on-remove="handleRemove"
      :before-remove="beforeRemove"
      multiple
      :limit="100"
      :on-exceed="handleExceed"
      :on-success="Success"
      :file-list="fileList">
      <el-button type="success">上传测试用例</el-button>
      <div class="el-upload__tip">只能上传excel文件</div>
    </el-upload>
  </div>
  <template>
    <el-table
      stripe
      :data="tableData"
      style="width: 100%">
      <el-table-column
        prop="id"
        label="用例编号"
        width="180">
      </el-table-column>
      <el-table-column
        prop="a"
        label="a"
        width="180">
      </el-table-column>
      <el-table-column
        prop="b"
        label="b"
        width="180">
      </el-table-column>
      <el-table-column
        prop="c"
        label="c"
        width="180">
      </el-table-column>
      <el-table-column
        prop="expect"
        label="预期结果"
        width="180">
      </el-table-column>
      <el-table-column
        prop="real"
        label="实际结果"
        width="180">
      </el-table-column>
      <el-table-column
        prop="result"
        label="是否通过"
        width="180">
      </el-table-column>
    </el-table>
  </template>
  </div>
</template>

<script>
export default {
  name: 'triangle',
  data () {
    return {
      tableData: [],
      tableData2: [],
      fileList: [],
      fileList2: []
    }
  },
  methods:
    {
      handleRemove (file, fileList) {
        console.log(file, fileList)
      },
      handlePreview (file) {
        console.log(file)
      },
      handleExceed (files, fileList) {
        this.$message.warning(`当前限制选择 100 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`)
      },
      // eslint-disable-next-line no-unused-vars
      beforeRemove (file, fileList) {
        return this.$confirm(`确定移除 ${file.name}？`)
      },

      // eslint-disable-next-line no-unused-vars
      Success (response, file, fileList) {
        this.tableData = response
      },
      handleRemove2 (file, fileList) {
        console.log(file, fileList)
      },
      handlePreview2 (file) {
        console.log(file)
      },
      handleExceed2 (files, fileList) {
        this.$message.warning(`当前限制选择 100 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`)
      },
      // eslint-disable-next-line no-unused-vars
      beforeRemove2 (file, fileList) {
        return this.$confirm(`确定移除 ${file.name}？`)
      },

      // eslint-disable-next-line no-unused-vars
      Success2 (response, file, fileList) {
        this.tableData2 = response
      }
    }
}
</script>

<style scoped>

</style>
