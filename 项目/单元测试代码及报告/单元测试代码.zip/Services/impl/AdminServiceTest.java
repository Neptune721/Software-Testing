package com.example.demo.Services.impl;

import com.example.demo.Services.AdminService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.DisplayName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Transactional
@Rollback
@SpringBootTest
class AdminServiceTest {

    @Autowired
    private AdminService adminService;

    @BeforeEach
    void setUp() {
        System.out.println("测试开始:");
    }

    @AfterEach
    void tearDown() {
        System.out.println("测试结束!");
    }

    @Test
    @DisplayName("测试GetBuyerIDForList方法")
    public void testGetBuyerIDForList() {
        List<String> buyerIDs = adminService.getBuyerIDForList();
        assertTrue(buyerIDs.size() > 0);
    }

    @Test
    @DisplayName("测试BlockBuyer方法，封禁买家")
    public void testBlockBuyer() {
        String buyerID = "10010";
        boolean result = adminService.blockBuyer(buyerID);
        assertTrue(result);

    }

    @Test
    @DisplayName("测试GetCommoditiesIDForList方法，获取商品列表")
    public void testGetCommoditiesIDForList() {
        List<String> commodityIDs = adminService.getCommoditiesIDForList();
        assertTrue(commodityIDs.size() > 0);
    }

    @Test
    @DisplayName("测试GetCommodityInfo方法")
    public void testGetCommodityInfo() {
        String commodityID = "100001";
        Map<String, Object> commodityInfo = adminService.getCommodityInfo(commodityID);
        assertTrue(commodityInfo.size() > 0);
    }

    @Test
    @DisplayName("测试WithdrawCommodity方法，删除商品")
    public void testWithdrawCommodity() {
        String commodityID = "100001";
        boolean result = adminService.withdrawCommodity(commodityID);
        assertTrue(result);

    }
}
