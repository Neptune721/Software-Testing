package com.example.demo.Services.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;


import com.example.demo.Services.ChangeService;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;


@Transactional
@Rollback
@SpringBootTest
public class ChangeServiceImplTest {

    @Autowired
    private ChangeService changeService;


    @Test
    @DisplayName("测试getGameIDForLibrary方法，密码和验证码正确")
    public void testGetGameIDForLibraryWithCorrectPasswordAndCode() {
        int result = changeService.getGameIDForLibrary("10002", "123456", "1234567", "268572");
        assertEquals(0, result);
    }

    @Test
    @DisplayName("测试getGameIDForLibrary方法，密码错误")
    public void testGetGameIDForLibraryWithIncorrectPassword() {
        int result = changeService.getGameIDForLibrary("10002", "1234567", "123456", "268572");
        assertEquals(-1, result);
    }

    @Test
    @DisplayName("测试getGameIDForLibrary方法，验证码错误")
    public void testGetGameIDForLibraryWithIncorrectCode() {
        int result = changeService.getGameIDForLibrary("10002", "123456", "123456", "654321");
        assertEquals(-2, result);
    }

    @Test
    @DisplayName("测试getGameIDForLibrary方法，验证码为空")
    public void testGetGameIDForLibraryWithNullCode() {
        int result = changeService.getGameIDForLibrary("10002", "123456", "123456", "");
        assertEquals(-2, result);
    }

    @Test
    @DisplayName("测试getGameIDForLibrary方法，密码为空")
    public void testGetGameIDForLibraryWithNullPassword() {
        int result = changeService.getGameIDForLibrary("10002", "", "123456", "268572");
        assertEquals(-1, result);
    }
}
