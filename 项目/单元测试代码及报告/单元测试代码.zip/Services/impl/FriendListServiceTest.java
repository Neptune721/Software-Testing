package com.example.demo.Services.impl;


import com.example.demo.Services.FriendListService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@Transactional
@Rollback
@SpringBootTest
class FriendListServiceTest {

    @Autowired
    private FriendListService friendListService;

    @BeforeEach
    void setUp() {
        System.out.println("测试开始:");
    }

    @AfterEach
    void tearDown() {
        System.out.println("测试结束!");
    }

    @Test
    public void testGetFriendIDForList() {
        String buyerID = "10001";
        List<String> idList = friendListService.getFriendIDForList(buyerID);
        assertNotNull(idList);
        assertTrue(idList.size() > 0);
    }

    @Test
    public void testGetFriendInfo() {
        String friendID = "10001";
        Map<String, Object> friendInfoMap = friendListService.getFriendInfo(friendID);
        assertNotNull(friendInfoMap);
        assertFalse(friendInfoMap.isEmpty());
        assertEquals("https://stargames-1314598070.cos.ap-nanjing.myqcloud.com/avatar/89bols22om.jpg", friendInfoMap.get("Avatar"));
        assertEquals("sun", friendInfoMap.get("BUYER_NAME"));
        assertEquals("2012-12-31", friendInfoMap.get("BIRTHDAY").toString());
        assertEquals("147258369@qq.com", friendInfoMap.get("MAIL"));
    }

    @Test
    public void testDeleteFriend() {
// 先添加一个好友
        String buyerID = "10001";
        String friendID = "10002";

        // 测试删除好友
        boolean deleteResult;
        // 测试输入参数任意为空的情况
        deleteResult = friendListService.deleteFriend("", "");
        assertFalse(deleteResult);

        // 测试输入参数非空但数据库不存在
        deleteResult = friendListService.deleteFriend(buyerID, "9999");
        assertFalse(deleteResult);

        // 测试输入参数正确
        deleteResult = friendListService.deleteFriend(buyerID, friendID);
        assertTrue(deleteResult);

    }

}
