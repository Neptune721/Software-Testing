package com.example.demo.Services.impl;

import com.example.demo.Services.LoginService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;


import static org.junit.jupiter.api.Assertions.*;

@Transactional
@Rollback
@SpringBootTest
class LoginServiceTest {

    @Autowired
    private LoginService loginService;

    @BeforeEach
    void setUp() {
        System.out.println("测试开始:");
    }

    @AfterEach
    void tearDown() {
        System.out.println("测试结束!");
    }

    @Test
    public void testCheckIdentity() {
        String userID = "10001";
        String password = "1234567";
        int result = loginService.checkIdentity(userID, password);
        assertTrue(result >=0);

        userID = "13888888888";
        result = loginService.checkIdentity(userID, password);
        assertEquals(result, -1);

        userID = "10001";
        password = "111111";
        result = loginService.checkIdentity(userID, password);
        assertEquals(result, -1);
    }

    @Test
    public void testGenerateUserID() {
        String result = loginService.generateUserID();
        assertTrue(result != null && result.length() == 5);
    }

    @Test
    public void testAddNewUser() {
        // 添加一个不存在的手机号用户
        String phoneNumber = "13999999999";
        String password = "123456";
        int userType = 0;
        boolean result = loginService.addNewUser(phoneNumber, password, userType);
        assertTrue(result);

        // 再次添加相同的手机号用户
        result = loginService.addNewUser(phoneNumber, password, userType);
        assertFalse(result);

    }
}
