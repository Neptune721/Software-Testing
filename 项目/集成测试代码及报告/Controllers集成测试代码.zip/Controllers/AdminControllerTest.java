package com.example.demo.Controllers;

import com.example.demo.Services.AdminService;
import com.example.demo.Services.BuyerInfoService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.List;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@SpringBootTest
@Transactional
@Rollback
@AutoConfigureMockMvc
class AdminControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AdminService adminService;

    @MockBean
    private BuyerInfoService buyerInfoService;

    @BeforeEach
    void setUp() {
        System.out.println("测试开始:");
    }

    @AfterEach
    void tearDown() {
        System.out.println("测试结束!");
    }

    @Test
    @DisplayName("测试AdminController中的GetBuyerListItems方法")
    public void testGetBuyerListItems() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        List<String> IDList = Arrays.asList("10001", "10002", "10003");
        when(adminService.getBuyerIDForList()).thenReturn(IDList);

        Map<String, Object> buyer1 = new HashMap<>();
        buyer1.put("id", "10001");
        buyer1.put("name", "sun");
        buyer1.put("age", 25);
        Map<String, Object> buyer2 = new HashMap<>();
        buyer2.put("id", "10002");
        buyer2.put("name", "Mlxg");
        buyer2.put("age", 30);
        Map<String, Object> buyer3 = new HashMap<>();
        buyer3.put("id", "10003");
        buyer3.put("name", "xiaohu");
        buyer3.put("age", 35);

        when(buyerInfoService.getBuyerInfo("10001")).thenReturn(buyer1);
        when(buyerInfoService.getBuyerInfo("10002")).thenReturn(buyer2);
        when(buyerInfoService.getBuyerInfo("10003")).thenReturn(buyer3);

        MvcResult result = mockMvc.perform(get("/api/v1/AdminService/BuyerListItems"))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        List<Map<String, Object>> list = objectMapper.readValue(content, new TypeReference<List<Map<String, Object>>>() {});

        assertEquals(3, list.size());
        assertEquals("10001", list.get(0).get("id"));
        assertEquals("Mlxg", list.get(1).get("name"));
        assertEquals(35, list.get(2).get("age"));
    }



    @Test
    @DisplayName("测试AdminController中的QueryBuyerItem方法")
    public void testQueryBuyerItem() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> buyer = new HashMap<>();
        buyer.put("id", "10001");
        buyer.put("name", "sun");
        buyer.put("age", 25);

        when(buyerInfoService.getBuyerInfo("10001")).thenReturn(buyer);

        MvcResult result = mockMvc.perform(get("/api/v1/AdminService/QueryBuyer").param("BuyerID", "10001"))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        List<Map<String, Object>> list = objectMapper.readValue(content, new TypeReference<List<Map<String, Object>>>() {});

        assertEquals(1, list.size());
        assertEquals("10001", list.get(0).get("id"));
        assertEquals("sun", list.get(0).get("name"));
        assertEquals(25, list.get(0).get("age"));
    }



    @Test
    @DisplayName("测试AdminController中的BlockBuyer方法")
    public void testBlockBuyer() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        when(adminService.blockBuyer("10001")).thenReturn(true);

        MvcResult result = mockMvc.perform(get("/api/v1/AdminService/BlockBuyer").param("BuyerID", "10001"))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        boolean isSuccess = objectMapper.readValue(content, Boolean.class);

        assertTrue(isSuccess);
    }

    @Test
    @DisplayName("测试AdminController中的GetCommodityListItems方法")
    public void testGetCommodityListItems() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        List<String> IDList = Arrays.asList("100001", "100002", "100003");
        when(adminService.getCommoditiesIDForList()).thenReturn(IDList);

        Map<String, Object> commodity1 = new HashMap<>();
        commodity1.put("id", "100001");
        commodity1.put("name", "God of War：Ragnarok");
        commodity1.put("price", 568.00);
        Map<String, Object> commodity2 = new HashMap<>();
        commodity2.put("id", "100002");
        commodity2.put("name", "Elden Ring");
        commodity2.put("price", 368.00);
        Map<String, Object> commodity3 = new HashMap<>();
        commodity3.put("id", "100003");
        commodity3.put("name", "地平线2：禁忌西部");
        commodity3.put("price", 498.00);

        when(adminService.getCommodityInfo("100001")).thenReturn(commodity1);
        when(adminService.getCommodityInfo("100002")).thenReturn(commodity2);
        when(adminService.getCommodityInfo("100003")).thenReturn(commodity3);

        MvcResult result = mockMvc.perform(get("/api/v1/AdminService/CommodityListItems"))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        List<Map<String, Object>> list = objectMapper.readValue(content, new TypeReference<List<Map<String, Object>>>() {});

        assertEquals(3, list.size());
        assertEquals("100001", list.get(0).get("id"));
        assertEquals("Elden Ring", list.get(1).get("name"));
        assertEquals(498.00, list.get(2).get("price"));
    }

    @Test
    @DisplayName("测试AdminController中的QueryCommodityItem方法")
    public void testQueryCommodityItem() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, Object> commodity = new HashMap<>();
        commodity.put("id", "100001");
        commodity.put("name", "God of War:Ragnarok");
        commodity.put("price", 568.00);

        when(adminService.getCommodityInfo("100001")).thenReturn(commodity);

        MvcResult result = mockMvc.perform(get("/api/v1/AdminService/QueryCommodity").param("CommodityID", "100001"))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        List<Map<String, Object>> list = objectMapper.readValue(content, new TypeReference<List<Map<String, Object>>>() {});

        assertEquals(1, list.size());
        assertEquals("100001", list.get(0).get("id"));
        assertEquals("God of War:Ragnarok", list.get(0).get("name"));
        assertEquals(568.0, list.get(0).get("price"));
    }



    @Test
    @DisplayName("测试AdminController中的WithdrawCommodity方法")
    public void testWithdrawCommodity() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        when(adminService.withdrawCommodity("100001")).thenReturn(true);

        MvcResult result = mockMvc.perform(get("/api/v1/AdminService/WithdrawCommodity").param("CommodityID", "100001"))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        boolean isSuccess = objectMapper.readValue(content, Boolean.class);

        assertTrue(isSuccess);
    }
}
