package com.example.demo.Controllers;

import com.example.demo.Services.ChangeService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@Transactional
@Rollback
@AutoConfigureMockMvc
public class ChangeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ChangeService changeService;

    @Test
    @DisplayName("测试getGameIDForLibrary方法，密码和验证码正确")
    public void testGetGameIDForLibraryWithCorrectPasswordAndCode() throws Exception {
        when(changeService.getGameIDForLibrary("10002", "123456", "1234567", "268572")).thenReturn(0);
        MvcResult result = mockMvc.perform(post("/api/v1/ChangeService/changePasswd")
                        .param("BuyerID", "10002")
                        .param("OldPasswd", "123456")
                        .param("NewPasswd", "1234567")
                        .param("Code", "268572"))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        assertEquals("0", content);
    }

    @Test
    @DisplayName("测试getGameIDForLibrary方法，密码错误")
    public void testGetGameIDForLibraryWithIncorrectPassword() throws Exception {
        when(changeService.getGameIDForLibrary("10002", "1234567", "123456", "268572")).thenReturn(-1);
        MvcResult result = mockMvc.perform(post("/api/v1/ChangeService/changePasswd")
                        .param("BuyerID", "10002")
                        .param("OldPasswd", "1234567")
                        .param("NewPasswd", "123456")
                        .param("Code", "268572"))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        assertEquals("-1", content);
    }

    @Test
    @DisplayName("测试getGameIDForLibrary方法，验证码错误")
    public void testGetGameIDForLibraryWithIncorrectCode() throws Exception {
        when(changeService.getGameIDForLibrary("10002", "123456", "123456", "654321")).thenReturn(-2);
        MvcResult result = mockMvc.perform(post("/api/v1/ChangeService/changePasswd")
                        .param("BuyerID", "10002")
                        .param("OldPasswd", "123456")
                        .param("NewPasswd", "123456")
                        .param("Code", "654321"))
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        assertEquals("-2", content);
    }

}
