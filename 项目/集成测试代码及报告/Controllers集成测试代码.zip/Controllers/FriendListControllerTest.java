package com.example.demo.Controllers;

import com.example.demo.Services.FriendListService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Transactional
@Rollback
@AutoConfigureMockMvc
public class FriendListControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FriendListService friendListService;

    @Test
    @DisplayName("测试 GetListItems 方法")
    public void testGetListItems() throws Exception {
        String buyerID = "10001";

        List<String> idList = new ArrayList<>();
        idList.add("10002");

        Map<String, Object> friendInfoMap = new HashMap<>();
        friendInfoMap.put("Avatar", "https://ts1.cn.mm.bing.net/th/id/R-C.e65f53c1f2855b817fa58ff85aea75b4?rik=mHnucf3ghql64g&riu=http%3a%2f%2fimg.sgamer.com%2flol_sgamer_com%2fimages%2f181119%2f546ff522bfcaf5a0c0b5768ba4169c46.jpeg&ehk=FjBdgj0UPZsDf1tEmjmyqDTZcI5pbE8N92nrZ05lRjU%3d&risl=&pid=ImgRaw&r=0&sres=1&sresct=1");
        friendInfoMap.put("BUYER_NAME", "Mlxg");
        friendInfoMap.put("BIRTHDAY", "1999-11-30");
        friendInfoMap.put("MAIL", "3239338381@qq.com");

        when(friendListService.getFriendIDForList(buyerID)).thenReturn(idList);
        when(friendListService.getFriendInfo("10002")).thenReturn(friendInfoMap);

        MvcResult result = mockMvc.perform(get("/api/v1/FriendListService/FriendListItems?BuyerID=10001"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andReturn();

        String jsonString = result.getResponse().getContentAsString();
        assertThat(jsonString).contains("BUYER_NAME").contains("Mlxg");
    }

    @Test
    @DisplayName("测试 DeleteFriend 方法")
    public void testDeleteFriend() throws Exception {
        String buyerID = "10001";
        String friendID = "10002";

        when(friendListService.deleteFriend(buyerID, friendID)).thenReturn(true);

        mockMvc.perform(get("/api/v1/FriendListService/DeleteFriend?BuyerID=10001&FriendID=10002"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("true")))
                .andReturn();
    }
}
