package com.example.demo.Controllers;

import com.example.demo.Services.LoginService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

@SpringBootTest
@Transactional
@Rollback
@AutoConfigureMockMvc
public class LoginControllerTest {
    @MockBean
    private LoginService loginService;

    @Autowired
    private MockMvc mockMvc;

    /**
     * 测试登录成功情况
     */
    @Test
    public void testLoginSuccess() throws Exception {
        String userID = "10001";
        String password = "1234567";

        when(loginService.checkIdentity(anyString(), anyString())).thenReturn(0);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/LoginService/Login")
                        .param("UserID", userID)
                        .param("Password", password)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(print())
                .andReturn();

        String contentAsString = result.getResponse().getContentAsString();
        System.out.println(contentAsString);

        assert (contentAsString.equals("0"));
    }

    /**
     * 测试登录失败情况
     */
    @Test
    public void testLoginFail() throws Exception {
        String userID = "10001";
        String password = "1234567";

        when(loginService.checkIdentity(anyString(), anyString())).thenReturn(-1);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/LoginService/Login")
                        .param("UserID", userID)
                        .param("Password", password)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(print())
                .andReturn();

        String contentAsString = result.getResponse().getContentAsString();
        System.out.println(contentAsString);

        assert (contentAsString.equals("-1"));
    }

    /**
     * 测试注册成功情况
     */
    @Test
    public void testRegisterSuccess() throws Exception {
        String phoneNumber = "13999999999";
        String password = "123456";
        int userType = 0;

        when(loginService.addNewUser(anyString(), anyString(), anyInt())).thenReturn(true);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/LoginService/Register")
                        .param("PhoneNumber", phoneNumber)
                        .param("Password", password)
                        .param("UserType", String.valueOf(userType))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(print())
                .andReturn();

        String contentAsString = result.getResponse().getContentAsString();
        System.out.println(contentAsString);

        assert (contentAsString.equals("true"));
    }

    /**
     * 测试注册失败情况
     */
    @Test
    public void testRegisterFail() throws Exception {
        String phoneNumber = "13888888888";
        String password = "123456";
        int userType = 0;

        when(loginService.addNewUser(anyString(), anyString(), anyInt())).thenReturn(false);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/LoginService/Register")
                        .param("PhoneNumber", phoneNumber)
                        .param("Password", password)
                        .param("UserType", String.valueOf(userType))
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(print())
                .andReturn();

        String contentAsString = result.getResponse().getContentAsString();
        System.out.println(contentAsString);

        assert (contentAsString.equals("false"));
    }
}
