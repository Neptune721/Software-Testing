import requests
import pandas as pd
urlBase = 'http://124.70.163.146:8080/api/v1'

def getRes():
    res = {}
    data_011 = ['10006', '10007']
    res['SG_Int_011_001'] = requests.get(url=urlBase + '/SellerService/SellerInfo?SellerID=' + data_011[0]).text
    res['SG_Int_011_002'] = requests.get(url=urlBase + '/SellerService/SellerInfo?SellerID=' + data_011[1]).text
    res['SG_Int_012_001'] = requests.get(url=urlBase + '/SellerService/Genres').text
    data_013 = ['100001', '100002', '100003']
    res['SG_Int_013_001'] = requests.get(url=urlBase + '/CommodityInfoService/CommodityFullInfo?CommodityID=' + data_013[0]).text
    res['SG_Int_013_002'] = requests.get(url=urlBase + '/CommodityInfoService/CommodityFullInfo?CommodityID=' + data_013[1]).text
    res['SG_Int_013_003'] = requests.get(url=urlBase + '/CommodityInfoService/CommodityFullInfo?CommodityID=' + data_013[2]).text    
    data_014 = ['10001', '10002', '10003']
    res['SG_Int_014_001'] = requests.get(url=urlBase + '/BuyerInfoService/BuyerInfo?BuyerID=' + data_014[0]).text  
    res['SG_Int_014_002'] = requests.get(url=urlBase + '/BuyerInfoService/BuyerInfo?BuyerID=' + data_014[1]).text   
    res['SG_Int_014_003'] = requests.get(url=urlBase + '/BuyerInfoService/BuyerInfo?BuyerID=' + data_014[2]).text    
    return res


total = 0
success = 0
fail = 0
df = pd.read_excel('集成测试.xlsx')
df.insert(loc=2, column='real', value='')
df.insert(loc=3, column='result', value='')
res = getRes()
for i in range(df.shape[0]):
    total += 1
    df.loc[i,'real'] = res[str(df.loc[i, 'id'])]
    if str(df.loc[i, 'real']) != str(df.loc[i, 'expect']):
        df.loc[i, 'result'] = "未通过测试"
        fail += 1
    else:
        df.loc[i, 'result'] = "通过测试"
        success += 1
df.to_csv('result.csv')
print('共测试了',total,'个测试用例,成功:',success,'失败:',fail)
